# Placas > 2022-04-05 9:50pm
https://universe.roboflow.com/xavier-jimenez/placas-stcpz

Provided by a Roboflow user
License: Public Domain

